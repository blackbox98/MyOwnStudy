$(document).ready(function () {
    const user = JSON.parse(localStorage.getItem("user"));
    var loadUser = '<input id="id" name="id" type="text" readonly value="' + user.id + '" />';
    loadUser += '<input id="password" name="password" type="text" readonly value="' + user.password + '" />';
    loadUser += '<input id="email" name="email" type="text" readonly value="' + user.email + '" />';
    loadUser += '<input id="name" name="name" type="text" readonly value="' + user.name + '" />';
    loadUser += '<input id="age" name="age" type="text" readonly value="' + user.age + '" />';
    loadUser += '<button class="close-btn" onclick="checkClose()" type="button">나가기</button>';

    $("form").append(loadUser);
});

function checkClose() {
    self.close();
}
