$(document).ready(function () {
    const user = JSON.parse(localStorage.getItem("user"));
    var loadUser = '<input id="id" name="id" type="text" readonly value="' + user.id + '" />';
    loadUser += '<input id="password" name="password" type="text" />';
    loadUser += '<input id="email" name="email" type="text" />';
    loadUser += '<input id="name" name="name" type="text" />';
    loadUser += '<input id="age" name="age" type="text" />';
    loadUser += '<button class="modify-info-btn" onclick="modifyInfo()" type="button">회원정보 수정</button>';

    $("form").append(loadUser);
});

function modifyInfo() {
    const user = JSON.parse(localStorage.getItem("user"));
    let id = user.id;
    // textbox에 readonly로 아이디를 출력

    let password = document.getElementById("password").value;
    let name = document.getElementById("name").value;
    let email = document.getElementById("email").value;
    let age = document.getElementById("age").value;

    // 입력값 검증
    if (id == "" || password == "" || name == "" || email == "" || age == "") {
        alert("빈칸이 없도록 입력해주세요.");
        return;
    } else {
        // input data로 user 만들기
        const user = {
            id: id,
            password: password,
            name: name,
            email: email,
            age: age,
        };

        // user 객체 문자열로 바꿔서 로컬스토리지에 저장
        localStorage.setItem("user", JSON.stringify(user));
        alert("회원정보가 정상적으로 수정되었습니다!");
        // 로그인 화면으로 돌아가기
        self.close();
    }
}
