$(document).ready(function () {
    const user = JSON.parse(localStorage.getItem("user"));
    var loadUser = '<input id="id" name="id" type="text" readonly value="' + user.id + '" />';
    loadUser += '<input id="password" name="password" type="text" readonly value="' + user.password + '" />';
    loadUser += '<input id="email" name="email" type="text" readonly value="' + user.email + '" />';
    loadUser += '<input id="name" name="name" type="text" readonly value="' + user.name + '" />';
    loadUser += '<input id="age" name="age" type="text" readonly value="' + user.age + '" />';
    loadUser += '<button class="deleteInfo-btn" onclick="deleteInfo()" type="button">회원 탈퇴</button>';

    $("form").append(loadUser);
});

function deleteInfo() {
    if (confirm("회원정보를 삭제하시겠습니까?")) {
        alert("회원정보가 삭제되었습니다!");
        localStorage.clear();
        self.close();
    } else {
        alert("회원정보 삭제가 취소되었습니다!");
        self.close();
    }
}
