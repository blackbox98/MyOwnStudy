package service;

import java.util.ArrayList;

import DAO.HouseDealInfoDAO;
import DTO.HouseDealInfo;
import DTO.ListParameterDTO;

public class HouseServiceImpl implements HouseService {
	
	private HouseDealInfoDAO housedealInfoDao = HouseDealInfoDAO.getHouseDealInfoDAO();
	
	private static HouseService houseService = new HouseServiceImpl();
	
	private HouseServiceImpl() {}

	public static HouseService getHouseService() {
		return houseService;
	}


	public ArrayList<HouseDealInfo> listDeal(String dong,String aptCode) throws Exception {
		// TODO Auto-generated method stub
		System.out.println("여기");
		ListParameterDTO listParameterDto=new ListParameterDTO();
		listParameterDto.setDong(dong==null?"":dong);
		listParameterDto.setAptCode(aptCode==null?"":aptCode);
		
		return housedealInfoDao.listHouseDeal(listParameterDto);
	}

	
	

}
