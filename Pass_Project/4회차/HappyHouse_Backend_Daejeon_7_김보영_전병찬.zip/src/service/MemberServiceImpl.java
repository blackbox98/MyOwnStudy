package service;

import java.sql.SQLException;
import java.util.ArrayList;

import DAO.MemberDAO;
import DAO.MemberDAOImpl;
import DTO.MemberDTO;

public class MemberServiceImpl implements MemberService {
	
	private MemberDAO memDao = MemberDAOImpl.getMemberDao();
	
	private static MemberService memberService = new MemberServiceImpl();
	
	private MemberServiceImpl() {}

	public static MemberService getMemberService() {
		return memberService;
	}

	@Override
	public MemberDTO login(String id, String pw) throws SQLException {
		return memDao.login(id, pw);
	}

	@Override
	public void modifyInfoMember(MemberDTO m) throws SQLException {
		memDao.modifyInfoMember(m);
	}

	@Override
	public void deleteInfoMember(MemberDTO m) throws SQLException {
		memDao.deleteInfoMember(m);
	}
	
	@Override
	public ArrayList<MemberDTO> listMember() throws SQLException {
		return memDao.listMember();
	}

	@Override
	public void joinMember(MemberDTO m) throws SQLException {
		memDao.joinMember(m);
	}

	@Override
	public String findpw(String id, String email) throws SQLException {
		return memDao.findpw(id, email);
	}
}
