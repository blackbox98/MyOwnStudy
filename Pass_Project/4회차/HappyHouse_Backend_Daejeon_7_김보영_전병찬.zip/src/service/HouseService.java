package service;

import java.util.ArrayList;

import DTO.HouseDealInfo;

public interface HouseService {
	
	ArrayList<HouseDealInfo> listDeal(String dong,String aptCode) throws Exception;
	
}