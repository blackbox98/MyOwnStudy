package controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import DTO.MemberDTO;
import service.MemberService;
import service.MemberServiceImpl;

/**
 * Servlet implementation class MemberServlet
 */
@WebServlet("/member")
public class MemberServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private MemberService memser = MemberServiceImpl.getMemberService();

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doGet(request, response);
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String act = request.getParameter("act");
		String path = "/index.jsp";
		System.out.println(act);
		try {
			if (act != null) {
				if (act.equals("initpage")) {
					path = "redirect:/index.jsp";
				} else if (act.equals("loginform")) {
					path = "/member/login.jsp";
				} else if (act.equals("login")) {
					path = login(request, response);
				} else if (act.equals("findPasswordform")) {
					path = findPassword(request, response);
				} else if (act.equals("findPassword")) {
					path = findPasswordMember(request, response);
				} else if (act.equals("joinform")) {
					path = join(request, response);
				} else if (act.equals("join")) {
					path = joinMember(request, response);
				} else if (act.equals("logout")) {
					path = loginOut(request, response);
				} else if (act.equals("mypage")) {
					path = "/member/my_page.jsp";
				} else if (act.equals("checkInfoform")) {
					path = checkInfoMember(request, response);
				} else if (act.equals("modifyInfoform")) {
					path = modifyInfo(request, response);
				} else if (act.equals("modifyInfo")) {
					path = modifyInfoMember(request, response);
				} else if (act.equals("deleteInfoform")) {
					path = deleteInfo(request, response);
				} else if (act.equals("deleteInfo")) {
					path = deleteInfoMember(request, response);
				} else if (act.equals("memberlist")) {
					path = listMember(request, response);
				}
			}
		} catch (Exception e) {
//			e.printStackTrace();
			request.setAttribute("exception", e);
			path = "/error/error.jsp";
		}
		if (path.startsWith("redirect")) {
			path = path.substring(path.indexOf(":") + 1);
			response.sendRedirect(request.getContextPath() + path);
		} else {
			request.getRequestDispatcher(path).forward(request, response);
		}
	}

	private String joinMember(HttpServletRequest request, HttpServletResponse response) throws SQLException {
		memser.joinMember(new MemberDTO(request.getParameter("id"), request.getParameter("password"),
				request.getParameter("email"), request.getParameter("name"), Integer.parseInt(request.getParameter("age"))));
		return "redirect:/member/login.jsp";
	}

	private String join(HttpServletRequest request, HttpServletResponse response) {
		return "/member/join.jsp";
	}

	private String findPasswordMember(HttpServletRequest request, HttpServletResponse response) throws SQLException {
		String id = request.getParameter("id");
		String email = request.getParameter("email");
		String pw = memser.findpw(id, email);
		if(!pw.equals("")) {
			request.setAttribute("msg", "비밀번호는 \"" + pw + "\" 입니다.");
		} else {
			request.setAttribute("msg", "등록되지 않은 계정입니다.");
		}
		return "member?act=loginform";
	}
	
	private String findPassword(HttpServletRequest request, HttpServletResponse response) {
		return "/member/find_password.jsp";
	}

	private String listMember(HttpServletRequest request, HttpServletResponse response) throws SQLException {
		ArrayList<MemberDTO> list = memser.listMember();
		request.setAttribute("memlist", list);
		return "/member/listmember.jsp";
	}

	private String deleteInfoMember(HttpServletRequest request, HttpServletResponse response) throws SQLException {
		memser.deleteInfoMember(new MemberDTO(request.getParameter("id"), request.getParameter("password"),
				request.getParameter("email"), request.getParameter("name"), Integer.parseInt(request.getParameter("age"))));
		Cookie[] cookies = request.getCookies();
		if (cookies != null) {
			for (int i = 0; i < cookies.length; i++) {
				if (cookies[i].getName().equals("id")) {
					cookies[i].setMaxAge(0);
					response.addCookie(cookies[i]);
					break;
				}
			}
		}
		HttpSession session = request.getSession();
		session.invalidate();
		return "member?act=initpage";
		
	}

	private String deleteInfo(HttpServletRequest request, HttpServletResponse response) {
		return "/member/delete_info.jsp";
	}

	private String modifyInfoMember(HttpServletRequest request, HttpServletResponse response) throws SQLException {
		memser.modifyInfoMember(new MemberDTO(request.getParameter("id"), request.getParameter("password"),
				request.getParameter("email"), request.getParameter("name"), Integer.parseInt(request.getParameter("age"))));
		MemberDTO memDto = new MemberDTO(request.getParameter("id"), request.getParameter("password"),
				request.getParameter("email"), request.getParameter("name"), Integer.parseInt(request.getParameter("age")));
		request.getSession().setAttribute("userInfo", memDto);
		return "redirect:/member/my_page.jsp";
	}

	private String modifyInfo(HttpServletRequest request, HttpServletResponse response) {
		return "/member/modify_info.jsp";
	}

	private String checkInfoMember(HttpServletRequest request, HttpServletResponse response) {
		return "/member/check_info.jsp";
	}

	private String login(HttpServletRequest request, HttpServletResponse response) {
		MemberDTO memDto = null;

		String id = request.getParameter("id");
		String pw = request.getParameter("password");
		try {
			memDto = memser.login(id, pw);
			if (memDto != null) { // 로그인 성공
				request.getSession().setAttribute("userInfo", memDto);

				String idsv = request.getParameter("idsave");
				if ("saveok".equals(idsv)) { // 아이디 저장 체크 O
					Cookie cookie = new Cookie("id", id);
					cookie.setMaxAge(60 * 60 * 10);
					cookie.setPath(request.getContextPath());
					response.addCookie(cookie);
				} else { // 아이디 저장 체크 X
					Cookie[] cookies = request.getCookies();
					if (cookies != null) {
						for (int i = 0; i < cookies.length; i++) {
							if (cookies[i].getName().equals("id")) {
								cookies[i].setMaxAge(0);
								response.addCookie(cookies[i]);
								break;
							}
						}
					}
				}
				return "member?act=initpage";
			} else { // 로그인 실패
				request.setAttribute("msg", "아이디 또는 비밀번호 확인 후 다시 로그인하세요.");
				return "member?act=loginform";
			}
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("msg", "로그인 처리 중 문제 발생!!");
			return "/error/error.jsp";
		}
	}

	private String loginOut(HttpServletRequest request, HttpServletResponse response) {
		HttpSession session = request.getSession();
		session.invalidate();
		return "member?act=initpage";
	}
}