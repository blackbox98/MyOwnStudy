package DAO;

import java.sql.SQLException;
import java.util.ArrayList;

import DTO.MemberDTO;

public interface MemberDAO {
	MemberDTO login(String id, String pass) throws SQLException;
	void modifyInfoMember(MemberDTO m) throws SQLException;
	void deleteInfoMember(MemberDTO m) throws SQLException;
	ArrayList<MemberDTO> listMember() throws SQLException;
	void joinMember(MemberDTO m) throws SQLException;
	String findpw(String id, String email) throws SQLException;
}