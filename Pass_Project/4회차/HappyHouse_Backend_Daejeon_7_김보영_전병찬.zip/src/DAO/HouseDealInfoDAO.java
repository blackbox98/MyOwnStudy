package DAO;

import java.sql.*;
import java.util.ArrayList;

import DTO.HouseDealDTO;
import DTO.HouseDealInfo;
import DTO.ListParameterDTO;
import util.DBUtil;


public class HouseDealInfoDAO {
	private static HouseDealInfoDAO housedealInfoDao=new HouseDealInfoDAO();
	
	public static HouseDealInfoDAO getHouseDealInfoDAO() {
		return housedealInfoDao;
	}
	
	private HouseDealInfoDAO() {}
	
	
	public ArrayList<HouseDealInfo> listHouseDeal(ListParameterDTO listParameterDto) throws SQLException {
		ArrayList<HouseDealInfo> list=new ArrayList<HouseDealInfo>();
		
		Connection conn=DBUtil.getConnection();
		StringBuilder listdeal=new StringBuilder();
		listdeal.append("select a.aptCode, a.aptName, a.dongName, a.jibun, a.lat,a.lng,b.dealAmount,b.dealYear,b.area from houseinfo a, housedeal b where a.aptCode=b.aptCode \n");
		String dong=listParameterDto.getDong();
		String aptCode=listParameterDto.getAptCode();
		//System.out.println("동이름:"+dong);
		
		if(!dong.isEmpty()) {
			listdeal.append("and a.dongName=? \n");
		}
		if(!aptCode.isEmpty()) {
			listdeal.append("and a.aptCode=?");
		}
		
		PreparedStatement pstmt=conn.prepareStatement(listdeal.toString());
		if(!dong.isEmpty()) {
			pstmt.setString(1, dong);
		}
		if(!aptCode.isEmpty()) {
			pstmt.setInt(1, Integer.parseInt(aptCode));
		}
		
		ResultSet rs=pstmt.executeQuery();
		
		
		
		while(rs.next()) {
			list.add(new HouseDealInfo(rs.getString("aptCode"),rs.getString("aptName"),rs.getString("dongName"),rs.getString("jibun"),rs.getString("lat"),rs.getString("lng"),rs.getString("dealAmount"),rs.getString("dealYear"),rs.getString("area")));
			
		}
		return list;
	}

	

	

	public void deleteHouseDeal(int no) {
		// num�� �ش��ϴ� �� ����
		Connection con = null;
		PreparedStatement st = null;
		try {
			con = DBUtil.getConnection();// 2
			String q = "Delete from housedeal  where no=" +no ;// 3
			st = con.prepareStatement(q);// 3
			st.executeUpdate();// 4
		} catch (SQLException e) {
			System.out.println("delete ����:" + e);
		} finally {
			try {
				// if(rs != null) rs.close();//6
				if (st != null)
					st.close();
				if (con != null)
					con.close();
			} catch (SQLException se) {
				se.printStackTrace();
			}
		}// end finally

	}// end deleteCustomer()
}// end class
