package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import DTO.MemberDTO;
import util.DBUtil;


/*
create table member(
		id varchar2(30) primary key,
		password varchar2(30),
		email varchar2(40),
		name varchar2(20),
		age int
);
*/
public class MemberDAOImpl implements MemberDAO{
	
	private static MemberDAO memDao = new MemberDAOImpl();
	
	private MemberDAOImpl() {}

	public static MemberDAO getMemberDao() {
		return memDao;
	}
	
	@Override
	public MemberDTO login(String id, String pw) throws SQLException {
		MemberDTO memDto = null;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			conn = DBUtil.getConnection();
			StringBuilder loginMember = new StringBuilder();
			loginMember.append("select * \n");
			loginMember.append("from member \n");
			loginMember.append("where id = ? and password = ? \n");
			pstmt = conn.prepareStatement(loginMember.toString());
			pstmt.setString(1, id);
			pstmt.setString(2, pw);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				memDto = new MemberDTO();
				memDto.setId(rs.getString("id"));
				memDto.setPassword(rs.getString("password"));
				memDto.setEmail(rs.getString("email"));
				memDto.setName(rs.getString("name"));
				memDto.setAge(rs.getInt("age"));
			}
		} finally {
			DBUtil.close(rs, pstmt, conn);
		}
		return memDto;
	}

	@Override
	public void modifyInfoMember(MemberDTO m) throws SQLException {
		Connection conn = DBUtil.getConnection();
		String sql = "update member set password=?, email=?, name=?, age=? where id=? ";
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, m.getPassword());
		pstmt.setString(2, m.getEmail());
		pstmt.setString(3, m.getName());
		pstmt.setInt(4, m.getAge());
		pstmt.setString(5, m.getId());
		pstmt.executeUpdate();
		DBUtil.close(pstmt,conn);
	}

	@Override
	public void deleteInfoMember(MemberDTO m) throws SQLException {
		System.out.println("gang! " + m);
		Connection conn = DBUtil.getConnection();
		String sql = "delete from member where id = ? ";
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, m.getId());
		pstmt.executeUpdate();
		DBUtil.close(pstmt,conn);
	}

	@Override
	public ArrayList<MemberDTO> listMember() throws SQLException {
		Connection conn = DBUtil.getConnection();
		String sql = "select id, password, email, name, age from member ";
		PreparedStatement pstmt = conn.prepareStatement(sql);
		ResultSet rs = pstmt.executeQuery();
		ArrayList<MemberDTO> list = new ArrayList<>();
		MemberDTO memDto = null;
		while(rs.next()) {
			memDto = new MemberDTO();
			memDto = new MemberDTO();
			memDto.setId(rs.getString("id"));
			memDto.setPassword(rs.getString("password"));
			memDto.setEmail(rs.getString("email"));
			memDto.setName(rs.getString("name"));
			memDto.setAge(rs.getInt("age"));
			System.out.println(memDto);
			list.add(memDto);
		}
		DBUtil.close(rs, pstmt, conn);
		return list;
	}

	@Override
	public void joinMember(MemberDTO m) throws SQLException {
		Connection conn = DBUtil.getConnection();
		String sql = "insert into member values(?, ?, ?, ?, ?)";
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, m.getId());
		pstmt.setString(2, m.getPassword());
		pstmt.setString(3, m.getEmail());
		pstmt.setString(4, m.getName());
		pstmt.setInt(5, m.getAge());
		pstmt.executeUpdate();
		DBUtil.close(pstmt, conn);
	}

	@Override
	public String findpw(String id, String email) throws SQLException {
		Connection conn = DBUtil.getConnection();
		String sql = "select password from member where id = ? and email = ? ";
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, id);
		pstmt.setString(2, email);
		ResultSet rs = pstmt.executeQuery();
		String pw = "";
		if(rs.next()) {
			pw = rs.getString(1);
		}
		return pw;
	}
}// end class