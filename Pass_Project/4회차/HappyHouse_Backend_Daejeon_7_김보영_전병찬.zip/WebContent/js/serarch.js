var map, marker;
let url = "https://grpc-proxy-server-mkvo6j4wsq-du.a.run.app/v1/regcodes";
let regcode = "*00000000";
// 전국 특별/광역시, 도
// https://grpc-proxy-server-mkvo6j4wsq-du.a.run.app/v1/regcodes?regcode_pattern=*00000000
$.ajax({
  url: url,
  type: "GET",
  data: {
    regcode_pattern: regcode,
  },
  dataType: "json",
  success: function (response) {
    let code = ``;
    $.each(response.regcodes, function (i, regcode) {
      code += `
            <option value="${regcode.code}">${regcode.name}</option>
            `;
    });
    $("#sido")
      .empty()
      .append('<option value="">시도선택</option>')
      .append(code);
  },
  error: function (xhr, status, msg) {
    console.log("상태값 : " + status + " Http에러메시지 : " + msg);
  },
});

$(document).on("change", "#sido", function () {
  regcode = $(this).val().substr(0, 2) + "*00000";
  $.ajax({
    url: url,
    type: "GET",
    data: {
      regcode_pattern: regcode,
      is_ignore_zero: true,
    },
    dataType: "json",
    success: function (response) {
      let code = ``;
      $.each(response.regcodes, function (i, regcode) {
        code += `
            <option value="${regcode.code}">${
          regcode.name.split(" ")[1]
        }</option>
            `;
      });
      $("#gugun")
        .empty()
        .append('<option value="">구군선택</option>')
        .append(code);
    },
    error: function (xhr, status, msg) {
      console.log("상태값 : " + status + " Http에러메시지 : " + msg);
    },
  });
});

$(document).on("change", "#gugun", function () {
  regcode = $(this).val().substr(0, 4) + "*";
  console.log(regcode);
  $.ajax({
    url: url,
    type: "GET",
    data: {
      regcode_pattern: regcode,
      is_ignore_zero: true,
    },
    dataType: "json",
    success: function (response) {
      let code = ``;
      $.each(response.regcodes, function (i, regcode) {
        code += `
            <option value="${regcode.name.split(" ")[2]}">${
          regcode.name.split(" ")[2]
        }</option>
            `;
      });
      //   console.log(code + " code ");
      $("#dong")
        .empty()
        .append('<option value="">동선택</option>')
        .append(code);
    },
    error: function (xhr, status, msg) {
      console.log("상태값 : " + status + " Http에러메시지 : " + msg);
    },
  });
});

function aptName(e) {
  // console.log($(e).attr("class"));
  var code = $(e).attr("class");
 
  // 데이터 출력
  //   document.getElementById("result").innerText = code;
  const xhr = new XMLHttpRequest();
  const method = "GET";
  const url2 = "data/AptDealHistory.xml";
  // 위의 method 와 url 로 비동기 요청 초기화
  xhr.open(method, url2, true);
  // 요청 헤더 설정
  xhr.setRequestHeader("Content-Type", "application/text");
  // 요청 동작 설정
  xhr.onreadystatechange = function () {
    if (xhr.readyState === xhr.DONE) {
      // 요청 상태가 OK 이면
      if (xhr.status === 200) {
        

        var apts = xhr.responseXML;
        // xml에서 책목록을 배열로 받음.
        var aptlist = apts.querySelectorAll("item");
        var len = aptlist.length;
        // var aptInfo = '<div><h3 id="apart_name">' + code + "</h3><br><hr>";
        var aptInfo ='';
        for (var i = 0; i < len; i++) {

          var apt = aptlist[i];
          var name = apt.querySelector("아파트").childNodes[0].nodeValue; // xml에서 isbn 얻기
          
          if (name == code) {
            var area = apt.querySelector("전용면적").childNodes[0].nodeValue; // xml에서 제목 얻기
            var price = apt.querySelector("거래금액").childNodes[0].nodeValue; // xml에서 가격 얻기
            var year = apt.querySelector("년").childNodes[0].nodeValue;
            var month = apt.querySelector("월").childNodes[0].nodeValue;
            var day = apt.querySelector("일").childNodes[0].nodeValue;
            aptInfo += '<tr class="' + name + '" onclick="aptName(this)">';
            aptInfo +=
              '<td id="apart_name" onclick="aptName(this)">' + name + "</td>";
            aptInfo += '<td id="apart_info">' + price + "</td>";
            aptInfo += ' <td id="apart_info">' + area + "</td>";
            aptInfo +=
              ' <td id="apart_date">' + year + "." + month + "." + day + "</td>";
            aptInfo += "</tr>";
          }
        }
        // 아이디가 plist인 div에 책화면을 html로 삽입.
        document.querySelector("#plist").innerHTML = aptInfo;
      }
    }
  };
  xhr.send(method == "POST" ? null : null);
}

function getDongList(e, n) {
	
	
	
	
	
	
  // 선택된 데이터 가져오기
  var code = e.value;
  // 데이터 출력
  //   document.getElementById("result").innerText = code;
  const xhr = new XMLHttpRequest();
  const method = "GET";
  const url2 = "data/AptDealHistory.xml";
  // 위의 method 와 url 로 비동기 요청 초기화
  xhr.open(method, url2, true);
  // 요청 헤더 설정
  xhr.setRequestHeader("Content-Type", "application/text");
  // 요청 동작 설정
  xhr.onreadystatechange = function () {
    if (xhr.readyState === xhr.DONE) {
      // 요청 상태가 OK 이면
      if (xhr.status === 200) {
        var apts = xhr.responseXML;
        // xml에서 책목록을 배열로 받음.
        var aptlist = apts.querySelectorAll("item");
        var len = aptlist.length;
        var aptInfo = "";
        console.log("dkdkdkdkdkd");
        for (var i = 0; i < len; i++) {
          var apt = aptlist[i];
          var code_name = apt
            .querySelector("법정동")
            .childNodes[0].nodeValue.replace(" ", "");
          if (code_name == code || (n == 2 && code == 1111000000) || n == 2) {
            var name = apt.querySelector("아파트").childNodes[0].nodeValue; // xml에서 isbn 얻기
            var area = apt.querySelector("전용면적").childNodes[0].nodeValue; // xml에서 제목 얻기
            var price = apt.querySelector("거래금액").childNodes[0].nodeValue; // xml에서 가격 얻기
            var year = apt.querySelector("년").childNodes[0].nodeValue;
            var month = apt.querySelector("월").childNodes[0].nodeValue;
            var day = apt.querySelector("일").childNodes[0].nodeValue;
            aptInfo += '<tr class="' + name + '" onclick="aptName(this)">';
            aptInfo +=
              '<td id="apart_name" onclick="aptName(this)">' + name + "</td>";
            aptInfo += '<td id="apart_info">' + price + "</td>";
            aptInfo += ' <td id="apart_info">' + area + "</td>";
            aptInfo +=
              ' <td id="apart_date">' + year + "." + month + "." + day + "</td>";
            aptInfo += "</tr>";
          }
        }
        // 아이디가 plist인 div에 책화면을 html로 삽입.
        document.querySelector("#plist").innerHTML = aptInfo;
      }
    }
  };

  // 요청 보내기
  xhr.send(method == "POST" ? null : null);
}

$(document).ready(function () {
  // 초기 kakao map 설정 start
  var container = document.getElementById("map"); //지도를 담을 영역의 DOM 레퍼런스
  // var lat = 37.5012743;
  // var lng = 127.039585;
  var locPosition = new kakao.maps.LatLng(37.5012743, 127.039585); // (멀티캠퍼스)
  var options = {
    //지도를 생성할 때 필요한 기본 옵션
    center: locPosition, //지도의 중심좌표.
    level: 3, //지도의 레벨(확대, 축소 정도)
  };

  map = new kakao.maps.Map(container, options); //지도 생성 및 객체 리턴

  // HTML5의 geolocation으로 사용할 수 있는지 확인합니다
  if (navigator.geolocation) {
    // GeoLocation을 이용해서 접속 위치를 얻어옵니다
    navigator.geolocation.getCurrentPosition(function (position) {
      var lat = position.coords.latitude, // 위도
        lon = position.coords.longitude; // 경도

      locPosition = new kakao.maps.LatLng(lat, lon); // 마커가 표시될 위치를 geolocation으로 얻어온 좌표로 생성합니다
      var message = '<div style="padding:5px;">현재위치인가요?!</div>'; // 인포윈도우에 표시될 내용입니다

      // 마커와 인포윈도우를 표시합니다
      displayMarker(locPosition, message);
    });
  } else {
    // HTML5의 GeoLocation을 사용할 수 없을때 마커 표시 위치와 인포윈도우 내용을 설정합니다

    locPosition = new kakao.maps.LatLng(33.450701, 126.570667);
    var message = "geolocation을 사용할수 없어요..";

    displayMarker(locPosition, message);
  }
  // 초기 kakao map 설정 end

  var cafeArea = {
    서울: ["역삼점", "선릉점"],
    대전: ["학하점", "봉명점"],
    구미: ["연수원점", "구미사업장"],
    광주: ["하남산단점", "광주역점"],
    부울경: ["부산사업장점", "녹산산단점"],
  };

  var officePosition = {
    역삼점: { lat: 37.500613, lng: 127.036431 },
    선릉점: { lat: 37.504268, lng: 127.048188 },
    학하점: { lat: 36.35536, lng: 127.298294 },
    봉명점: { lat: 36.358843, lng: 127.344192 },
    연수원점: { lat: 36.098594, lng: 128.38977 },
    구미사업장: { lat: 36.109553, lng: 128.415011 },
    하남산단점: { lat: 35.204279, lng: 126.807198 },
    광주역점: { lat: 35.165476, lng: 126.909216 },
    부산사업장점: { lat: 35.095765, lng: 128.856344 },
    녹산산단점: { lat: 35.093641, lng: 128.855679 },
  };

  var officeAddress = {
    역삼점: "서울특별시+강남구+역삼동+테헤란로+212",
    선릉점: "서울특별시 강남구 역삼동 테헤란로 334 LG 화재빌딩",
    학하점: "대전광역시 유성구 덕명동 124",
    봉명점: "대전광역시 유성구 봉명동 대학로 60 봉명가든 6층",
    연수원점: "경상북도 구미시 공단동 259",
    구미사업장: "경상북도 구미시 임수동 94",
    하남산단점: "107 하남산단6번로 광산구 광주광역시",
    광주역점: "광주광역시 북구 중흥동 611",
    부산사업장점: "부산광역시 강서구 송정동 녹산산업중로 삼성전기 부산사업장사",
    녹산산단점: "부산광역시 강서구 송정동 삼성전기부속의원",
  };

  $(".dropdown-item.area").click(function () {
    var selArea = $(this).text();
    $("#areaBtn").text(selArea);
    $("#officeBtn").text("지점선택");
    var offices = cafeArea[selArea];
    $("#office_div").empty();
    $.each(offices, function (i, office) {
      $("#office_div").append(
        '<label class="dropdown-item cafe_office">' + office + "</label>"
      );
    });
  });

  //officePosition의 lat, lng를 이용한 marker
  $(document).on("click", ".dropdown-item.cafe_office", function () {
    var selOffice = $(this).text();
    $("#officeBtn").text(selOffice);
    var office = officePosition[selOffice];

    // 이동할 위도 경도 위치를 생성합니다
    var moveLatLon = new kakao.maps.LatLng(office.lat, office.lng);
    var message = `<div style="padding:5px;">${selOffice}</div>`;

    // 지도 중심을 부드럽게 이동시킵니다
    // 만약 이동할 거리가 지도 화면보다 크면 부드러운 효과 없이 이동합니다
    map.panTo(moveLatLon);

    displayMarker(moveLatLon, message);
  });
});

function displayMarker(locPosition, message) {
  if (marker) marker.setMap(null); // 기존 maker 제거

  var imageSrc = "img/my_position.png", // 마커이미지의 주소입니다
    imageSize = new kakao.maps.Size(50, 70), // 마커이미지의 크기입니다
    imageOption = { offset: new kakao.maps.Point(27, 69) }; // 마커이미지의 옵션입니다. 마커의 좌표와 일치시킬 이미지 안에서의 좌표를 설정합니다.

  // 마커의 이미지정보를 가지고 있는 마커이미지를 생성합니다
  var markerImage = new kakao.maps.MarkerImage(
    imageSrc,
    imageSize,
    imageOption
  );

  // 마커를 생성합니다
  marker = new kakao.maps.Marker({
    map: map,
    position: locPosition,
    image: markerImage,
  });

  var iwContent = message, // 인포윈도우에 표시할 내용
    iwRemoveable = true;

  // 인포윈도우를 생성합니다
  var infowindow = new kakao.maps.InfoWindow({
    content: iwContent,
    removable: iwRemoveable,
  });

  // 인포윈도우를 마커위에 표시합니다
  infowindow.open(map, marker);

  // 지도 중심좌표를 접속위치로 변경합니다
  map.setCenter(locPosition);
}
