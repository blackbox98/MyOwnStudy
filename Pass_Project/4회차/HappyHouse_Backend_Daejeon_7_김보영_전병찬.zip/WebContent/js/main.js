var map, marker;
var Items;
var geocoder = new kakao.maps.services.Geocoder();
window.onload = function () {
//    // sessionStorage를 활용해 현재 로그인 여부 관리
//    if (sessionStorage.getItem("loginCheck")) {
//        document.querySelector("#header_nav_logout").style.display = "none";
//        document.querySelector("#header_nav_login").style.display = "inline-block";
//        const user = JSON.parse(localStorage.getItem("user"));
//        // 회원정보 출력
//        console.log(JSON.parse(JSON.stringify(user)));
//        // 로그인 버튼 클릭 -> console에 로그인 출력
//        console.log("로그인");
//    } else {
//        document.querySelector("#header_nav_login").style.display = "none";
//        document.querySelector("#header_nav_logout").style.display = "inline-block";
//        // 로그아웃 버튼 클릭 -> console에 로그아웃 출력
//        console.log("로그아웃");
//    }
    if (!document.querySelector("#aptlist")) return;

    // 비동기 통신을 위해 새로운 xmlhttp 요청 생성
    const xhr = new XMLHttpRequest();
    // 요청 method
    const method = "GET";
    // 파일 위치
    const url = "./data/AptDealHistory.xml";

    // 위의 method 와 url 로 비동기 요청 초기화
    xhr.open(method, url, false);
    // 요청 헤더 설정
    xhr.setRequestHeader("Content-Type", "application/text");
    // 요청 동작 설정

    xhr.onreadystatechange = function () {
        if (xhr.readyState === xhr.DONE && xhr.status === 200) {
            const resDoc = xhr.responseXML;
            Items = resDoc.querySelectorAll("item");
            let len = Items.length;
            var ItemView = "";
            for (let i = 0; i < len; i++) {
                let item = Items[i];
                var 거래금액 = item.querySelector("거래금액").childNodes[0].nodeValue;
                var 건축년도 = item.querySelector("건축년도").childNodes[0].nodeValue;
                var 년 = item.querySelector("년").childNodes[0].nodeValue;
                var 법정동 = item.querySelector("법정동").childNodes[0].nodeValue;
                var 아파트 = item.querySelector("아파트").childNodes[0].nodeValue;
                var 지번 = item.querySelector("지번").childNodes[0].nodeValue;
                ItemView += `
                <tr>
                    <td>${아파트}</td>
                    <td>${거래금액}</td>
                    <td>${건축년도}</td>
                    <td>${법정동}</td>
                </tr>
                `;

                $("#aptlist").empty().append(ItemView);

                geocoder.addressSearch(법정동 + " " + 지번, function (result, status) {
                    // 검색 완료 여부
                    if (status === kakao.maps.services.Status.OK) {
                        var selLatLng = new kakao.maps.LatLng(result[0].y, result[0].x);
                        // 결과값으로 받은 위치를 마커로 표시합니다
                        var marker = new kakao.maps.Marker({
                            map: map,
                            position: selLatLng,
                            clickalbe: true,
                        });
                        marker.setMap(map);
                        // 인포윈도우로 장소에 대한 설명을 표시합니다
                        var infowindow = new kakao.maps.InfoWindow({
                            content: `<div style="width:150px;text-align:center;padding:6px 0;">${
                                item.querySelector("아파트").childNodes[0].nodeValue
                            }</div>`,
                            removable: true,
                        });

                        kakao.maps.event.addListener(marker, "click", function () {
                            // 마커 위에 인포윈도우를 표시합니다
                            infowindow.open(map, marker);

                            let len = Items.length;
                            var ItemView = "";
                            for (let i = 0; i < len; i++) {
                                let item = Items[i];
                                var 거래금액 =
                                    item.querySelector("거래금액").childNodes[0].nodeValue;
                                var 건축년도 =
                                    item.querySelector("건축년도").childNodes[0].nodeValue;
                                var 년 = item.querySelector("년").childNodes[0].nodeValue;
                                var 법정동 = item.querySelector("법정동").childNodes[0].nodeValue;
                                var 아파트 = item.querySelector("아파트").childNodes[0].nodeValue;
                                var 지번 = item.querySelector("지번").childNodes[0].nodeValue;

                                var htmlname =
                                    infowindow.a.childNodes[1].childNodes[0].childNodes[0]
                                        .nodeValue;
                                htmlname = JSON.stringify(htmlname);

                                if (!String(htmlname).includes(아파트)) {
                                    continue;
                                }
                                ItemView += `<div class="apartlist">
                <tr>
                    <td>${아파트}</td>
                    <td>${거래금액}</td>
                    <td>${건축년도}</td>
                    <td>${법정동}</td>
                </tr></div>
                `;
                            }
                            document.querySelector("#aptlist").innerHTML = ItemView;
                        });
                    }
                });
            }
            document.querySelector("#aptlist").innerHTML = ItemView;
        }
    };
    // 요청 보내기
    xhr.send();
    $(document).ready(function () {
        // 초기 kakao map 설정 start
        var container = document.getElementById("map"); //지도를 담을 영역의 DOM 레퍼런스
        // var lat = 37.5012743;
        // var lng = 127.039585;
        var locPosition = new kakao.maps.LatLng(37.5012743, 127.039585); // (멀티캠퍼스)
        var options = {
            //지도를 생성할 때 필요한 기본 옵션
            center: locPosition, //지도의 중심좌표.
            level: 3, //지도의 레벨(확대, 축소 정도)
        };

        map = new kakao.maps.Map(container, options); //지도 생성 및 객체 리턴
        // HTML5의 geolocation으로 사용할 수 있는지 확인합니다
        if (navigator.geolocation) {
            // GeoLocation을 이용해서 접속 위치를 얻어옵니다
            navigator.geolocation.getCurrentPosition(function (position) {
                var lat = position.selLatLng.latitude, // 위도
                    lon = position.selLatLng.longitude; // 경도

                locPosition = new kakao.maps.LatLng(lat, lon); // 마커가 표시될 위치를 geolocation으로 얻어온 좌표로 생성합니다
                var message = '<div style="padding:5px;">현재 위치인가요?!</div>'; // 인포윈도우에 표시될 내용입니다

                // 마커와 인포윈도우를 표시합니다
                // displayMarker(locPosition, message);
            });
        } else {
            // HTML5의 GeoLocation을 사용할 수 없을때 마커 표시 위치와 인포윈도우 내용을 설정합니다

            locPosition = new kakao.maps.LatLng(33.450701, 126.570667);
            var message = "geolocation을 사용할수 없어요..";

            displayMarker(locPosition, message);
        }
        // 초기 kakao map 설정 end
        var cafeArea = {
            서울: [
                "필운동",
                "사직동",
                "내수동",
                "익선동",
                "인의동",
                "이화동",
                "충신동",
                "동숭동",
                "명륜1가",
                "숭인동",
                "평동",
                "홍파동",
                "교북동",
                "평창동",
                "무악동",
                "당주동",
                "수송동",
                "행촌동",
            ],
        };

        $(".dropdown-item.cafe_area").click(function () {
            var selArea = $(this).text();
            $("#areaBtn").text(selArea);
            $("#officeBtn").text("지역선택");
            var offices = cafeArea[selArea];
            $("#office_div").empty();
            $.each(offices, function (i, office) {
                $("#office_div").append(
                    '<label class="dropdown-item cafe_office">' + office + "</label>"
                );
            });
        });

        //officePosition의 lat, lng를 이용한 marker
        $(document).on("click", ".dropdown-item.cafe_office", function () {
            var selOffice = $(this).text();
            $("#officeBtn").text(selOffice);
            // var office = officePosition[selOffice];
            geocoder.addressSearch(selOffice, function (result, status) {
                // 정상적으로 검색이 완료됐으면
                if (status === kakao.maps.services.Status.OK) {
                    var selLatLng = new kakao.maps.LatLng(result[0].y, result[0].x);
                    map.setCenter(selLatLng);
                }
                let len = Items.length;
                var ItemView = "";
                for (let i = 0; i < len; i++) {
                    let item = Items[i];
                    var 거래금액 = item.querySelector("거래금액").childNodes[0].nodeValue;
                    var 건축년도 = item.querySelector("건축년도").childNodes[0].nodeValue;
                    var 년 = item.querySelector("년").childNodes[0].nodeValue;
                    var 법정동 = item.querySelector("법정동").childNodes[0].nodeValue;
                    var 아파트 = item.querySelector("아파트").childNodes[0].nodeValue;
                    var 지번 = item.querySelector("지번").childNodes[0].nodeValue;

                    if (!법정동.includes(selOffice)) {
                        continue;
                    }
                    ItemView += `<div class="apartlist">
                <tr>
                    <td>${아파트}</td>
                    <td>${거래금액}</td>
                    <td>${건축년도}</td>
                    <td>${법정동}</td>
                </tr></div>
                `;
                }
                document.querySelector("#aptlist").innerHTML = ItemView;
            });
        });
    });
};

function regist() {
    // 문서에서 id 로 input data 가져오기
    let id = document.getElementById("id").value;
    let password = document.getElementById("password").value;
    let name = document.getElementById("name").value;
    let email = document.getElementById("email").value;
    let age = document.getElementById("age").value;

    // 입력값 검증
    if (id == "" || password == "" || name == "" || email == "" || age == "") {
        alert("빈칸이 없도록 입력해주세요.");
        return;
    } else {
        // input data로 user 만들기
        const user = {
            id: id,
            password: password,
            name: name,
            email: email,
            age: age,
        };

        // user 객체 문자열로 바꿔서 로컬스토리지에 저장
        localStorage.setItem("user", JSON.stringify(user));
        alert("사용자 등록 성공!");
        // 입력된 회원정보 출력
        console.log(JSON.parse(JSON.stringify(user)));
        // 로그인 화면으로 돌아가기
        location.replace("login.html");
    }
}

function login() {
    // 문서에서 id로 input data 가져오기
    let id = document.getElementById("id").value;
    let password = document.getElementById("password").value;

    // 로컬스토리지에 "user" 키로 저장된 item 가져와서 json 객체로 만들기
    const user = JSON.parse(localStorage.getItem("user"));

    if (user != null) {
        // 입력값 검증
        if (id == user.id && password == user.password) {
            alert("로그인 성공 !");
            // sessionStorage를 활용해 현재 로그인 여부 관리
            sessionStorage.setItem("loginCheck", true);
            // 로그인 성공 시 해당 회원의 ID와 Password 출력
            console.log("ID : " + id + ", Password : " + password);
            // 로그인 버튼 클릭 -> console에 로그인 출력
            console.log("로그인");
            // 로그인 성공하면 index 페이지로 이동.
            location.replace("index.html");
        } else {
            alert("로그인 실패 !");
        }
    } else {
        alert("등록된 회원이 없습니다.\n회원가입을 해주세요!");
    }
}

function logout() {
    // sessionStorage를 활용해 현재 로그인 여부 관리
    sessionStorage.removeItem("loginCheck");
    // 로그아웃 버튼 클릭 -> console에 로그아웃 출력
    console.log("로그아웃");
    location.replace("index.html");
}

function findPass() {
    // 문서에서 id로 input data 가져오기
    let id = document.getElementById("id").value;
    let email = document.getElementById("email").value;

    // 로컬스토리지에 "user" 키로 저장된 item 가져와서 json 객체로 만들기
    const user = JSON.parse(localStorage.getItem("user"));

    if (user != null) {
        // 입력값 검증
        if (id == user.id && email == user.email) {
            alert("비밀번호는 " + user.password + " 입니다.");
            // 로그인 성공하면 index 페이지로 이동.
            location.replace("login.html");
        } else if (id == user.id && email != user.email) {
            alert("해당 ID에 등록된 이메일이 아닙니다.");
        } else if (id != user.id) {
            alert("등록되지 않은 아이디입니다.");
        }
    } else {
        alert("등록된 회원이 없습니다.\n회원가입을 해주세요!");
    }
}

function openCheckInfo() {
    if (localStorage.getItem("user") != null) {
        // check_info.html의 창 아이디를 Check_Info로 설정하고 가로 400, 세로 600인 창 열기
        window.open("check_info.html", "Check_Info", "width=460,height=500,top=150,left=530");
    } else {
        alert("등록된 회원이 없습니다.");
    }
}

function openDeleteInfo() {
    // delete_info.html의 창 아이디를 Delete_Info로 설정하고 가로 400, 세로 600인 창 열기
    window.open("delete_info.html", "Delete_Info", "width=460,height=500,top=150,left=530");
}

function openModifyInfo() {
    // modify_info.html의 창 아이디를 Modify_Info로 설정하고 가로 400, 세로 600인 창 열기
    window.open("modify_info.html", "Modify_Info", "width=460,height=500,top=150,left=530");
}
