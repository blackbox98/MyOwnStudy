package hw.ssafy.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import hw.ssafy.dto.BoardDTO;
import hw.ssafy.dto.MemDTO;
import hw.ssafy.service.BoardService;
import hw.ssafy.service.BoardServiceImpl;

@WebServlet("*.brd")
public class BoardServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private String url = "";
	private BoardService boardser = BoardServiceImpl.getBoardService();

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);

	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path = request.getServletPath();
		System.out.println(path);
		try {
			if (path != null) {
				if (path.equals("/writeform.brd")) {
					url = "board/writeboard.jsp";
				} else if (path.equals("/insertboard.brd")) {
					url = insertBoard(request, response);
				} else if (path.equals("/deleteboard.brd")) {
					url = deleteBoard(request, response);
				} else if (path.equals("/listboard.brd")) {
					url = listBoard(request, response);
				} else if (path.equals("/updateboard.brd")) {
					url = updateBoard(request, response);
				} else if (path.equals("/changebrdInfo.brd")) {
					url = "board/ud_dl_board.jsp";
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("exception", e);
			url = "error/error.jsp";
		}
		if (url.startsWith("redirect")) {
			url = url.substring(url.indexOf(":") + 1);
			response.sendRedirect(url);
		} else {
			request.getRequestDispatcher(url).forward(request, response);
		}
	}
	
	private String insertBoard(HttpServletRequest request, HttpServletResponse response) throws SQLException {
		HttpSession session = request.getSession();
		MemDTO memDto = (MemDTO) session.getAttribute("userInfo");
		if(memDto != null) {
			BoardDTO boardDto = new BoardDTO();
			boardDto.setId(memDto.getId());
			boardDto.setTitle(request.getParameter("title"));
			boardDto.setContent(request.getParameter("content"));
			try {
				boardser.insertBoard(boardDto);
				return "/board/writesuccess.jsp";
			} catch (Exception e) {
				e.printStackTrace();
				request.setAttribute("msg", "게시글 작성 중 에러가 발생하였습니다!");
				return "/error/error.jsp";
			}
		} else {			
			return "loginform.do";
		}
	}
	
	private String listBoard(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, IOException {
		HttpSession session = request.getSession();
		MemDTO memDto = (MemDTO) session.getAttribute("userInfo");
		if(memDto != null) {
			try {
				ArrayList<BoardDTO> list = boardser.listBoard();
				request.setAttribute("boards", list);
				
				return "/board/listboard.jsp";
			} catch (Exception e) {
				e.printStackTrace();
				request.setAttribute("msg", "게시글 목록을 얻어오는 중 에러가 발생하였습니다!");
				return "/error/error.jsp";
			}
		} else {			
			return "loginform.do";
		}
	}
	
	private String deleteBoard(HttpServletRequest request, HttpServletResponse response) throws SQLException {
		HttpSession session = request.getSession();
		MemDTO memDto = (MemDTO) session.getAttribute("userInfo");
		if(memDto != null) {
			BoardDTO boardDto = new BoardDTO();
			boardDto.setNo(Integer.parseInt(request.getParameter("no")));
			try {
				boardser.deleteBoard(boardDto);
				return "listboard.brd";
			} catch (Exception e) {
				e.printStackTrace();
				request.setAttribute("msg", "게시글 작성 중 에러가 발생하였습니다!");
				return "/error/error.jsp";
			}
		} else {			
			return "redirect:listboard.brd";
		}
	}

	private String updateBoard(HttpServletRequest request, HttpServletResponse response) throws SQLException {
		HttpSession session = request.getSession();
		MemDTO memDto = (MemDTO) session.getAttribute("userInfo");
		if(memDto != null) {
			BoardDTO boardDto = new BoardDTO();
			boardDto.setTitle(request.getParameter("title"));
			boardDto.setContent(request.getParameter("content"));
			boardDto.setNo(Integer.parseInt(request.getParameter("no")));
			try {
				boardser.updateBoard(boardDto);
				return "/board/writesuccess.jsp";
			} catch (Exception e) {
				e.printStackTrace();
				request.setAttribute("msg", "게시글 수정 중 에러가 발생하였습니다!");
				return "/error/error.jsp";
			}
		} else {			
			return "redirect:listboard.brd";
		}
	}
}