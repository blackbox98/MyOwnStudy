package hw.ssafy.dto;

public class BoardDTO {
	private int no;
	private String id;
	private String name;
	private String title;
	private String content;
	private String regTime;

	public int getNo() {
		return no;
	}

	public void setNo(int no) {
		this.no = no;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getRegTime() {
		return regTime;
	}

	public void setRegTime(String regTime) {
		this.regTime = regTime;
	}

	@Override
	public String toString() {
		return "BoardDTO [no=" + no + ", id=" + id + ", name=" + name + ", title=" + title + ", content=" + content
				+ ", regTime=" + regTime + "]";
	}
}