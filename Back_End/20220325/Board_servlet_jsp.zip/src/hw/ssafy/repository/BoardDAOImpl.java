package hw.ssafy.repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import hw.ssafy.dto.BoardDTO;
import hw.ssafy.util.DBUtil;

public class BoardDAOImpl implements BoardDAO {

	private static BoardDAO boardDao = new BoardDAOImpl();

	private BoardDAOImpl() {
	}

	public static BoardDAO getBoardDao() {
		return boardDao;
	}

	@Override
	public void insertBoard(BoardDTO boardDto) throws SQLException {
		Connection conn = DBUtil.getConnection();
		PreparedStatement pstmt = null;
		try {
			String sql = "insert into boards (id, title, content, regTime) values (?, ?, ?, now()) ";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, boardDto.getId());
			pstmt.setString(2, boardDto.getTitle());
			pstmt.setString(3, boardDto.getContent());
			pstmt.executeUpdate();
		} finally {
			DBUtil.close(pstmt, conn);
		}
	}
	
	@Override
	public ArrayList<BoardDTO> listBoard() throws SQLException {
		ArrayList<BoardDTO> list = new ArrayList<BoardDTO>();
		Connection conn = DBUtil.getConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			String sql = "select b.no, b.id, b.title, b.content, b.regTime, m.name "
						+ "from boards b, members m "
						+ "where b.id = m.id "
						+ "order by b.no desc ";
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				BoardDTO boardDto = new BoardDTO();
				boardDto.setNo(rs.getInt("no"));
				boardDto.setId(rs.getString("id"));
				boardDto.setName(rs.getString("name"));
				boardDto.setTitle(rs.getString("title").replace("<", "&lt;"));
				boardDto.setContent(rs.getString("content"));
				boardDto.setRegTime(rs.getString("regTime"));
				
				list.add(boardDto);
			}
		} finally {
			DBUtil.close(rs, pstmt, conn);
		}
		return list;
	}
	
	@Override
	public void deleteBoard(BoardDTO boardDto) throws SQLException {
		Connection conn = DBUtil.getConnection();
		String sql = "delete from boards where no = ? ";
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setInt(1, boardDto.getNo());
		pstmt.executeUpdate();
		DBUtil.close(pstmt, conn);
	}
	
	@Override
	public void updateBoard(BoardDTO boardDto) throws SQLException {
		Connection conn = DBUtil.getConnection();
		String sql = "update boards set title=?, content=?, regTime=now() where no = ? ";
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, boardDto.getTitle());
		pstmt.setString(2, boardDto.getContent());
		pstmt.setInt(3, boardDto.getNo());
		pstmt.executeUpdate();
		DBUtil.close(pstmt, conn);
	}
}