package hw.ssafy.repository;

import java.sql.SQLException;
import java.util.ArrayList;

import hw.ssafy.dto.BoardDTO;

public interface BoardDAO {
	public void insertBoard(BoardDTO boardDto) throws SQLException;
	public ArrayList<BoardDTO> listBoard() throws SQLException;
	public void updateBoard(BoardDTO boardDto) throws SQLException;
	public void deleteBoard(BoardDTO boardDto) throws SQLException;
}