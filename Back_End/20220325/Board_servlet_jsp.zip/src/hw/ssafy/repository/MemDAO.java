package hw.ssafy.repository;

import java.sql.SQLException;
import java.util.ArrayList;

import hw.ssafy.dto.MemDTO;

public interface MemDAO {
	
	public int idCheck(String id);
	
	public MemDTO login(String id, String pw) throws SQLException;
	
	public void regMember(MemDTO m) throws SQLException;
	
	public ArrayList<MemDTO> listMember() throws SQLException;
	
	public void deleteMember(MemDTO m) throws SQLException;
	
	public void updateMember(MemDTO m) throws SQLException;
}