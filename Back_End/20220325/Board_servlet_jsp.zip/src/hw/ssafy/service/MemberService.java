package hw.ssafy.service;

import java.sql.SQLException;
import java.util.ArrayList;

import hw.ssafy.dto.MemDTO;

public interface MemberService {
	int idCheck(String id);
	MemDTO login(String id, String pass) throws Exception;
	public void regMember(MemDTO m) throws SQLException;
	public ArrayList<MemDTO> listMember() throws Exception;
	public void deleteMember(MemDTO m) throws SQLException;
	public void updateMember(MemDTO m) throws SQLException;
}
