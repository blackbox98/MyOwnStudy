package hw.ssafy.service;

import java.sql.SQLException;
import java.util.ArrayList;

import hw.ssafy.dto.MemDTO;
import hw.ssafy.repository.MemDAO;
import hw.ssafy.repository.MemDAOImpl;

public class MemberServiceImpl implements MemberService  {
	
	private MemDAO memDao = MemDAOImpl.getMemberDao();
	
	private static MemberService memberService = new MemberServiceImpl();
	
	private MemberServiceImpl() {}

	public static MemberService getMemberService() {
		return memberService;
	}

	@Override
	public int idCheck(String id) {
		return memDao.idCheck(id);
	}
	@Override
	public MemDTO login(String id, String pass) throws Exception {
		return memDao.login(id, pass);
	}

	@Override
	public void regMember(MemDTO m) throws SQLException {
		memDao.regMember(m);
	}

	@Override
	public ArrayList<MemDTO> listMember() throws Exception {
		return memDao.listMember();
	}
	
	@Override
	public void deleteMember(MemDTO m) throws SQLException {
		memDao.deleteMember(m);
	}

	@Override
	public void updateMember(MemDTO m) throws SQLException {
		memDao.updateMember(m);
	}
}