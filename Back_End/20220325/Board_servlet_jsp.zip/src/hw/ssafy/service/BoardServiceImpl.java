package hw.ssafy.service;

import java.sql.SQLException;
import java.util.ArrayList;

import hw.ssafy.dto.BoardDTO;
import hw.ssafy.repository.BoardDAO;
import hw.ssafy.repository.BoardDAOImpl;

public class BoardServiceImpl implements BoardService {

	private BoardDAO boardDao = BoardDAOImpl.getBoardDao();
	
	private static BoardService boardService = new BoardServiceImpl();
	
	private BoardServiceImpl() {}

	public static BoardService getBoardService() {
		return boardService;
	}

	@Override
	public void insertBoard(BoardDTO b) throws SQLException {
		boardDao.insertBoard(b);
	}

	@Override
	public ArrayList<BoardDTO> listBoard() throws SQLException {
		return boardDao.listBoard();
	}

	@Override
	public void updateBoard(BoardDTO b) throws SQLException {
		boardDao.updateBoard(b);
	}

	@Override
	public void deleteBoard(BoardDTO b) throws SQLException {
		boardDao.deleteBoard(b);
	}
}