package hw.ssafy.service;

import java.sql.SQLException;
import java.util.ArrayList;

import hw.ssafy.dto.BoardDTO;

public interface BoardService {
	public void insertBoard(BoardDTO b) throws SQLException;
	public ArrayList<BoardDTO> listBoard() throws SQLException;
	public void updateBoard(BoardDTO b) throws SQLException;
	public void deleteBoard(BoardDTO b) throws SQLException;
}