package hw.ssafy.dto;

public class ProDTO {
	String no;
	String name;
	String category;
	String price;
	String count;
	
	public ProDTO(String no, String name, String category, String price, String count) {
		super();
		this.no = no;
		this.name = name;
		this.category = category;
		this.price = price;
		this.count = count;
	}

	public String getNo() {
		return no;
	}

	public void setNo(String no) {
		this.no = no;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}
	
	public String getCount() {
		return count;
	}

	public void setCount(String count) {
		this.count = count;
	}

	@Override
	public String toString() {
		return "ProDTO [no=" + no + ", name=" + name + ", category=" + category + ", price=" + price + ", count=" + count + "]";
	};
}