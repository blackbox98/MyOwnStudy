package hw.ssafy.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import hw.ssafy.dto.ProDTO;
import hw.ssafy.repository.ProDAO;

/**
 * Servlet implementation class FrontController
 */
@WebServlet("*.do")
public class FrontController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private String url = "";
	private ProDAO proDAO;

	@Override
	public void init() throws ServletException {
		proDAO = new ProDAO();
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path = request.getServletPath();
		try {
			if (path != null) {
				if (path.equals("/regproduct.do")) {
					url = regProduct(request, response);
				} else if (path.equals("/listproduct.do")) {
					url = listProduct(request, response);
				} else if (path.equals("/initpage.do")) {
					url = "redirect:index.html";
				} else if (path.equals("/regproductform.do")) {
					url = "product/regproduct.html";
				} else if (path.equals("/viewproduct.do")) {
					url = "product/viewproduct.jsp";
				} else if(path.equals("/delproduct.do")) {
					url = deleteProduct(request,response); 
				} else if(path.equals("/updateproduct.do")) {
					url = updateProduct(request,response); 
				}
			}
		} catch (Exception e) {
//			e.printStackTrace();
			request.setAttribute("exception", e);
			url = "error/error.jsp";
		}
		if (url.startsWith("redirect")) {
			url = url.substring(url.indexOf(":") + 1);
			response.sendRedirect(url);
		} else {
			request.getRequestDispatcher(url).forward(request, response);
		}
	}

	private String regProduct(HttpServletRequest request, HttpServletResponse response) throws SQLException {
		String no = request.getParameter("no");
		String name = request.getParameter("name");
		String category = request.getParameter("category");
		String price = request.getParameter("price");
		String count = request.getParameter("count");
		System.out.printf("%s %s %s %s %s\n", no, name, category, price, count);
		proDAO.regProduct(new ProDTO(no, name, category, price, count));
		return "redirect:listproduct.do";
	}

	private String listProduct(HttpServletRequest request, HttpServletResponse response) throws SQLException {
		ArrayList<ProDTO> list = proDAO.listProduct();
		request.setAttribute("list", list);
		
		return "product/listproduct.jsp";
	}

	private String deleteProduct(HttpServletRequest request, HttpServletResponse response) throws NumberFormatException, SQLException {
		proDAO.deleteProduct(new ProDTO(request.getParameter("no")
				, request.getParameter("name")
				, request.getParameter("category")
				, request.getParameter("price")
				, request.getParameter("count")));
		return "redirect:listproduct.do";
	}

	private String updateProduct(HttpServletRequest request, HttpServletResponse response) throws NumberFormatException, SQLException {
		proDAO.updateProduct(new ProDTO(request.getParameter("no")
				, request.getParameter("name")
				, request.getParameter("category")
				, request.getParameter("price")
				, request.getParameter("count")));
		return "redirect:listproduct.do";
	}
}