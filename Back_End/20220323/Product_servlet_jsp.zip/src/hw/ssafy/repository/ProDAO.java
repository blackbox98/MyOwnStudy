package hw.ssafy.repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import hw.ssafy.dto.ProDTO;
import hw.ssafy.util.DBUtil;

public class ProDAO {
	public void regProduct(ProDTO m) throws SQLException {
		Connection conn = DBUtil.getConnection();
		String sql = "insert into products values(?, ?, ?, ?, ?)";
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setInt(1, Integer.parseInt(m.getNo()));
		pstmt.setString(2, m.getName());
		pstmt.setString(3, m.getCategory());
		pstmt.setString(4, m.getPrice());
		pstmt.setInt(5, Integer.parseInt(m.getCount()));
		pstmt.executeUpdate();
		System.out.println("0000000");
		DBUtil.close(pstmt, conn);
		System.out.println("1111111");
	}
	
	public ArrayList<ProDTO> listProduct() throws SQLException {
		Connection conn = DBUtil.getConnection();
		String sql = "select no, name, category, price, count from products";
		PreparedStatement pstmt = conn.prepareStatement(sql);
		ResultSet rs = pstmt.executeQuery();
		ArrayList<ProDTO> list = new ArrayList<>();
		while(rs.next()) {
			list.add(new ProDTO(rs.getString("no")
					, rs.getString("name")
					, rs.getString("category")
					, rs.getString("price")
					, rs.getString("count")));
		}
		return list;
	}
	
	public void deleteProduct(ProDTO m) throws SQLException {
		Connection conn = DBUtil.getConnection();
		String sql = "delete from products where no = ? ";
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, m.getNo());
		pstmt.executeUpdate();
		DBUtil.close(pstmt,conn);
	}
	
	public void updateProduct(ProDTO m) throws SQLException {
		Connection conn = DBUtil.getConnection();
		String sql = "update products set name=?, category=?, price=?, count=? where no=? ";
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, m.getName());
		pstmt.setString(2, m.getCategory());
		pstmt.setString(3, m.getPrice());
		pstmt.setInt(4, Integer.parseInt(m.getCount()));
		pstmt.setInt(5, Integer.parseInt(m.getNo()));
		pstmt.executeUpdate();
		DBUtil.close(pstmt,conn);
	}
}