package com.ssafy.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import edu.ssafy.dto.MemDTO;
import edu.ssafy.repository.MemDAO;

/**
 * Servlet implementation class FrontController
 */
@WebServlet("*.do")
public class FrontController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private String url = "";
	private MemDAO memDAO;

	@Override
	public void init() throws ServletException {
		memDAO = new MemDAO();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String path = request.getServletPath();
		System.out.println(path);
		try {
			if (path != null) {
				if (path.equals("/get.do")) {
					url = getTest(request, response);
				} else if (path.equals("/post.do")) {
					url = postTest(request, response);
				} else if (path.equals("/regmember.do")) {
					url = regmember(request, response);
				} else if (path.equals("/forward.do")) {
					// servlet에서 servlet 호출

					// forward방식
					String name = request.getParameter("name");
					name += "길동";
					request.setAttribute("name", name);
//					request.getRequestDispatcher("next.do").forward(request, response);

					// include방식
//					request.getRequestDispatcher("next.do").include(request, response);
//					PrintWriter out = response.getWriter();
//					out.write("front page");

					url = "next.do";
				} else if (path.equals("/sendredirect.do")) {
					// response.sendRedirect("next.do");
					url = "redirect:next.do";
				} else if (path.equals("/listmember.do")) {
					url = listMember(request, response);
				} else if (path.equals("/initpage.do")) {
					url = "redirect:index.html";
				} else if (path.equals("/regmemberform.do")) {
					url = "member/regmember.html";
				} else if (path.equals("/viewmember.do")) {
//					String id = request.getParameter("id");
//					String pw = request.getParameter("pw");
//					String name = request.getParameter("name");
//					String addr = request.getParameter("addr");
//					String age = request.getParameter("age");
//					System.out.printf("%s %s %s %s %s\n", id, pw, name, addr, age);
//					System.out.println("viewmember.do");
//					
//					request.setAttribute("id", id);
//					request.setAttribute("ew", pw);
//					request.setAttribute("name", name);
//					request.setAttribute("addr", addr);
//					request.setAttribute("age", age);
					url = "member/viewmember.jsp";
				} else if(path.equals("/delmember.do")) {
					url = deleteMember(request,response); 
				} else if(path.equals("/updatemember.do")) {
					url = updateMember(request,response); 
				}
			}
		} catch (Exception e) {
//			e.printStackTrace();
			request.setAttribute("exception", e);
			url = "error/error.jsp";
		}
		if (url.startsWith("redirect")) {
			url = url.substring(url.indexOf(":") + 1);
			response.sendRedirect(url);
		} else {
			request.getRequestDispatcher(url).forward(request, response);
		}
	}

	private String deleteMember(HttpServletRequest request, HttpServletResponse response) throws SQLException {
		memDAO.deleteMember(new MemDTO(request.getParameter("id")
										, request.getParameter("pw")
										, request.getParameter("name")
										, request.getParameter("addr")
										, request.getParameter("age")));
		return "redirect:listmember.do";
	}

	private String updateMember(HttpServletRequest request, HttpServletResponse response) throws SQLException {
		memDAO.updateMember(new MemDTO(request.getParameter("id")
										, request.getParameter("pw")
										, request.getParameter("name")
										, request.getParameter("addr")
										, request.getParameter("age")));
		return "redirect:listmember.do";
	}

	private String listMember(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, ServletException, IOException {
		ArrayList<MemDTO> list = memDAO.listMember();
		request.setAttribute("list", list);
//		request.getRequestDispatcher("member/listmember.jsp").forward(request, response);
		return "member/listmember.jsp";
	}

	private String regmember(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, IOException {
		String id = request.getParameter("id");
		String pw = request.getParameter("pw");
		String name = request.getParameter("name");
		String addr = request.getParameter("addr");
		String age = request.getParameter("age");
		System.out.printf("%s %s %s %s %s\n", id, pw, name, addr, age);
		memDAO.regMember(new MemDTO(id, pw, name, addr, age));

//		PrintWriter out = response.getWriter();
//		out.write("<h1>입력성공</h1>");
//		out.write("<a href=index.html>초기화면</a>");
//		out.flush();
//		out.close();
//		request.setAttribute("result", "입력성공");

		return "redirect:listmember.do";
	}

	private String postTest(HttpServletRequest request, HttpServletResponse response) throws IOException {
		String name = request.getParameter("name");
		String age = request.getParameter("age");
		String[] values = request.getParameterValues("hobby");
		System.out.println(name + " " + age);
		System.out.println(Arrays.toString(values));

//		PrintWriter out = response.getWriter();
//		out.write("<h1>" + name + ", " + age + "</h1>");
//		out.write("<h1>" + Arrays.toString(values) + "</h1>");
//		out.flush();

		request.setAttribute("res", "<h1>" + name + "," + age + "</h1>" + "<h1>" + Arrays.toString(values) + "</h1>");
		return "WEB-INF/result.jsp";
	}

	private String getTest(HttpServletRequest request, HttpServletResponse response) throws IOException {
		String name = request.getParameter("name");
		String age = request.getParameter("age");
		System.out.println(name + ", " + age);

//		PrintWriter out = response.getWriter();
//		out.write("<h1>" + name + ", " + age + "</h1>");
//		out.flush();

		request.setAttribute("res", "<h1>" + name + "," + age + "</h1>");
		return "WEB-INF/result.jsp";
	}
}