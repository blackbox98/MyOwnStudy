package hw.ssafy.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import hw.ssafy.dto.MemDTO;
import hw.ssafy.repository.MemDAO;
import hw.ssafy.service.MemberServiceImpl;

@WebServlet("*.do")
public class FrontController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private String url = "";
	private MemDAO memDAO;
	private MemberServiceImpl memberService = MemberServiceImpl.getMemberService();
	
	@Override
	public void init() throws ServletException {
		memDAO = new MemDAO();
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String path = request.getServletPath();
		System.out.println(path);
		try {
			if (path != null) {
				if (path.equals("/regmember.do")) {
					url = regmember(request, response);
				} else if (path.equals("/listmember.do")) {
					url = listMember(request, response);
				} else if (path.equals("/initpage.do")) {
					url = "redirect:index.jsp";
				} else if (path.equals("/regmemberform.do")) {
					url = "member/join.jsp";
				} else if (path.equals("/viewmember.do")) {
					url = "member/list.jsp";
				} else if(path.equals("/delmember.do")) {
					url = deleteMember(request,response); 
				} else if(path.equals("/updatemember.do")) {
					url = updateMember(request,response); 
				} else if (path.equals("/idcheck.do")) {
					////////////////////////////////////
					int cnt = idCheck(request, response);
					response.getWriter().append(cnt + "");
					////////////////////////////////////
				} else if (path.equals("/loginform.do")) {
					url = "member/login.jsp";
				} else if (path.equals("/login.do")) {
					url = loginMember(request, response);
				} else if (path.equals("/logout.do")) {
					url = loginOutMember(request, response);
				}
			}
		} catch (Exception e) {
//			e.printStackTrace();
			request.setAttribute("exception", e);
			url = "error/error.jsp";
		}
		if (url.startsWith("redirect")) {
			url = url.substring(url.indexOf(":") + 1);
			response.sendRedirect(url);
		} else {
			request.getRequestDispatcher(url).forward(request, response);
		}
	}
	
	private String deleteMember(HttpServletRequest request, HttpServletResponse response) throws SQLException {
		memDAO.deleteMember(new MemDTO(request.getParameter("id")
										, request.getParameter("pw")
										, request.getParameter("name")
										, request.getParameter("email")
										, request.getParameter("age")));
		return "redirect:listmember.do";
	}

	private String updateMember(HttpServletRequest request, HttpServletResponse response) throws SQLException {
		memDAO.updateMember(new MemDTO(request.getParameter("id")
										, request.getParameter("pw")
										, request.getParameter("name")
										, request.getParameter("email")
										, request.getParameter("age")));
		return "redirect:listmember.do";
	}

	private String listMember(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, ServletException, IOException {
		ArrayList<MemDTO> list = memDAO.listMember();
		request.setAttribute("memlist", list);
		return "viewmember.do";
	}

	private String regmember(HttpServletRequest request, HttpServletResponse response)
			throws SQLException, IOException {
		String id = request.getParameter("id");
		String pw = request.getParameter("pw");
		String name = request.getParameter("name");
		String email = request.getParameter("email");
		String age = request.getParameter("age");
		System.out.printf("%s %s %s %s %s\n", id, pw, name, email, age);
		memDAO.regMember(new MemDTO(id, pw, name, email, age));
		return "redirect:listmember.do";
	}
	
	private int idCheck(HttpServletRequest request, HttpServletResponse response) {
		int cnt = 1;
		String id = request.getParameter("ckid");
		cnt = memberService.idCheck(id);
		return cnt;
	}
	
	private String loginMember(HttpServletRequest request, HttpServletResponse response) {
		MemDTO memDto = null;
		
		String id = request.getParameter("id");
		String pass = request.getParameter("pw");

		try {
			memDto = memberService.login(id, pass);
			if (memDto != null) { // 로그인 성공
//				Session setting
				HttpSession session = request.getSession();
				session.setAttribute("userInfo", memDto);

				String idsv = request.getParameter("idsave");
				if ("saveok".equals(idsv)) { // 아이디 저장 체크
//					Cookie setting
					Cookie cookie = new Cookie("loginid", id);
					cookie.setMaxAge(60 * 60 * 2);
					cookie.setPath(request.getContextPath());
					response.addCookie(cookie);
				} else { // 아이디 저장 체크 X
					Cookie[] cookies = request.getCookies();
					if(cookies != null) {
						for(int i = 0; i < cookies.length; i++) {
							if(cookies[i].getName().equals("loginid")) {
								cookies[i].setMaxAge(0);
								response.addCookie(cookies[i]);
								break;
							}
						}
					}
				}
				return "initpage.do";
			} else { // 로그인 실패
				request.setAttribute("msg", "아이디 또는 비밀번호 확인 후 다시 로그인하세요.");
				return "loginform.do";
			}
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("msg", "로그인 처리 중 문제 발생!!");
			return "/error/error.jsp";
		}
	}

	private String loginOutMember(HttpServletRequest request, HttpServletResponse response) {
		HttpSession session = request.getSession();
		session.invalidate();
		return "initpage.do";
	}
}