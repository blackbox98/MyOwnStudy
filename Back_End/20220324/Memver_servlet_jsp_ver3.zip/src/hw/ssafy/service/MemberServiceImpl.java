package hw.ssafy.service;

import hw.ssafy.dto.MemDTO;
import hw.ssafy.repository.MemDAO;

public class MemberServiceImpl {
	
	private MemDAO memDao = MemDAO.getMemberDao();
	
	private static MemberServiceImpl memberService = new MemberServiceImpl();
	
	private MemberServiceImpl() {}

	public static MemberServiceImpl getMemberService() {
		return memberService;
	}

	public int idCheck(String id) {
		return memDao.idCheck(id);
	}
	
	public void registerMember(MemDTO memDto) throws Exception {
		memDao.regMember(memDto);
	}

	public MemDTO login(String id, String pass) throws Exception {
		return memDao.login(id, pass);
	}
}