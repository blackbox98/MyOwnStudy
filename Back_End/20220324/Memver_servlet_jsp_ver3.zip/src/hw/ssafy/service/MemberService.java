package hw.ssafy.service;

import hw.ssafy.dto.MemDTO;

public interface MemberService {

	int idCheck(String id);
	void registerMember(MemDTO memDto) throws Exception;
	MemDTO login(String id, String pass) throws Exception;
}
