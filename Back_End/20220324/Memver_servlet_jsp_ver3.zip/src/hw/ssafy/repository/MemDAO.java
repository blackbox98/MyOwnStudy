package hw.ssafy.repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import hw.ssafy.dto.MemDTO;
import hw.ssafy.util.DBUtil;

public class MemDAO {

	public static MemDAO getMemberDao() {
		return new MemDAO();
	}
	
	public int idCheck(String id){
		int cnt = 1;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			conn = DBUtil.getConnection();
			String sql = "select count(id) from members where id = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			rs.next();
			cnt = rs.getInt(1);
		} catch (Exception e) {
			e.printStackTrace();
			cnt = 1;
		} finally {
			DBUtil.close(rs, pstmt, conn);
		}
		return cnt;
	}
	
	public MemDTO login(String id, String pw) throws SQLException {
		MemDTO memDto = null;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			conn = DBUtil.getConnection();
			String sql = "select id, pw, name, email, age from members where id = ? and pw = ?";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, id);
			pstmt.setString(2, pw);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				memDto = new MemDTO(rs.getString("id")
									, rs.getString("pw")
									, rs.getString("name")
									, rs.getString("email")
									, rs.getString("age"));
			}
		} finally {
			DBUtil.close(rs, pstmt, conn);
		}
		return memDto;
	}
	
	public void regMember(MemDTO m) throws SQLException {
		Connection conn = DBUtil.getConnection();
		String sql = "insert into members values(?, ?, ?, ?, ?)";
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, m.getId());
		pstmt.setString(2, m.getPw());
		pstmt.setString(3, m.getName());
		pstmt.setString(4, m.getEmail());
		pstmt.setInt(5, Integer.parseInt(m.getAge()));
		pstmt.executeUpdate();
		DBUtil.close(pstmt, conn);
	}
	
	public ArrayList<MemDTO> listMember() throws SQLException {
		Connection conn = DBUtil.getConnection();
		String sql = "select id, pw, name, email ,age from members ";
		PreparedStatement pstmt = conn.prepareStatement(sql);
		ResultSet rs = pstmt.executeQuery();
		ArrayList<MemDTO> list = new ArrayList<>();
		while(rs.next()) {
			list.add(new MemDTO(rs.getString("id")
					, rs.getString("pw"), rs.getString("name")
					, rs.getString("email"), rs.getString("age")));
		}
		return list;
	}
	
	public void deleteMember(MemDTO m) throws SQLException {
		Connection conn = DBUtil.getConnection();
		String sql = "delete from members where id = ? ";
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, m.getId());
		pstmt.executeUpdate();
		DBUtil.close(pstmt,conn);
	}
	
	public void updateMember(MemDTO m) throws SQLException {
		Connection conn = DBUtil.getConnection();
		String sql = "update members set pw=?, name=?, email=?, age=? where id=? ";
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, m.getPw());
		pstmt.setString(2, m.getName());
		pstmt.setString(3, m.getEmail());
		pstmt.setInt(4, Integer.parseInt(m.getAge()));
		pstmt.setString(5, m.getId());
		pstmt.executeUpdate();
		DBUtil.close(pstmt,conn);
	}
}